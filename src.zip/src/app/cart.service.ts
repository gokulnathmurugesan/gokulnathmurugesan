import { Injectable } from '@angular/core';
import{HttpClient}from '@angular/common/http';
import { Observable } from 'rxjs';
import { cart } from './products';
@Injectable({
  providedIn: 'root'
})
export class CartService {
items=[];
products:cart;
 private purchaseUrl: string;
 private viewUrl: string;
constructor(
  private http:HttpClient
) {
  this.purchaseUrl='http://localhost:3000/productss';
this.viewUrl='http://localhost:3000/products';
}
public findAll(): Observable<cart[]> {
  return this.http.get<cart[]>(this.viewUrl);
}

public save(products: cart) {
 
  console.log(products);
  return this.http.post(this.purchaseUrl,products);
}

addToCart(product: any){
  this.items.push(product);
}
getItems(){
  return this.items;
}
clearCart(){
  this.items=[];
  return this.items;
}
getShippingPrices(){
  return this.http.get('/assets/shipping.json');
}
}
